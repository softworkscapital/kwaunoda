export const API_URL = 'http://192.168.66.7:3011';
// export const API_URL = 'https://srv547457.hstgr.cloud:3011';
export const GOOGLE_MAPS_API_KEY = 'AIzaSyA4ZQWDwYRHmhu66Cb1F8DgXbJJrArHYyE';
